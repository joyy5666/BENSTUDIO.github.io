import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might want to show this error in the UI.
  // For this exercise, we throw an error to halt execution if the key is missing.
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const SYSTEM_INSTRUCTION_GENERATE = `You are an expert Lua programmer. Your task is to generate clean, efficient, and well-commented Lua code based on the user's request. 
Always enclose the final Lua code within a single markdown code block like this:
\`\`\`lua
-- your code here
\`\`\`
Do not include any other explanatory text, greetings, or sign-offs outside of the code block. The code should be complete and ready to use.`;

const SYSTEM_INSTRUCTION_DEBUG = `You are an expert Lua debugger and programmer. You will be given a Lua script that contains an error, along with a description of the error.
Your task is to analyze the script and the error, identify the problem, and provide the fully corrected Lua script.
- Return ONLY the complete, corrected Lua code.
- Enclose the final Lua code within a single markdown code block.
- Add comments within the code where you've made significant changes to explain the fix.
- Do not include any other explanatory text, greetings, or apologies outside of the code block.

Example:
User provides a script with a syntax error and the message "error near 'then'".
You should return:
\`\`\`lua
-- Fixed: Added 'do' keyword after the for loop declaration
for i = 1, 10 do
  if i % 2 == 0 then
    print(i)
  end
end
\`\`\`
`;


/**
 * Generates a Lua script using the Gemini API.
 * @param userPrompt The custom prompt from the user.
 * @returns The generated Lua script as a string.
 */
export const generateScript = async (userPrompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: userPrompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_GENERATE,
        temperature: 0.5,
        topP: 0.95,
        topK: 64,
        maxOutputTokens: 8192,
      },
    });

    const text = response.text;
    
    // Extract code from the markdown block
    const codeBlockMatch = text.match(/```lua\n([\s\S]*?)\n```/);
    if (codeBlockMatch && codeBlockMatch[1]) {
      return codeBlockMatch[1].trim();
    }
    
    // Fallback if the model doesn't follow instructions perfectly
    console.warn("Model did not return code in a markdown block. Returning raw text.");
    return text.trim().replace(/^```lua\n?/, '').replace(/```$/, '');

  } catch (error) {
    console.error("Error generating script:", error);
    if (error instanceof Error) {
        return `Error: Failed to generate script. Please check your API key and network connection. Details: ${error.message}`;
    }
    return "Error: An unknown error occurred while generating the script.";
  }
};

/**
 * Fixes an error in a Lua script using the Gemini API.
 * @param script The Lua script with an error.
 * @param errorContext The description of the error.
 * @returns The fixed Lua script as a string.
 */
export const solveError = async (script: string, errorContext: string): Promise<string> => {
  if (!script.trim() || !errorContext.trim()) {
    return "Error: Please provide both the script and the error description.";
  }

  const userPrompt = `
Here is the Lua script with an error:
\`\`\`lua
${script}
\`\`\`

Here is the error message or context I'm getting:
"${errorContext}"

Please analyze the script and the error, and provide the corrected version of the script.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: userPrompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_DEBUG,
        temperature: 0.3, // Lower temperature for more deterministic fixes
        topP: 0.95,
        topK: 64,
        maxOutputTokens: 8192,
      },
    });

    const text = response.text;
    
    // Extract code from the markdown block
    const codeBlockMatch = text.match(/```lua\n([\s\S]*?)\n```/);
    if (codeBlockMatch && codeBlockMatch[1]) {
      return codeBlockMatch[1].trim();
    }
    
    // Fallback if the model doesn't follow instructions perfectly
    console.warn("Model did not return code in a markdown block. Returning raw text.");
    return text.trim().replace(/^```lua\n?/, '').replace(/```$/, '');

  } catch (error) {
    console.error("Error solving script error:", error);
    if (error instanceof Error) {
        return `Error: Failed to solve script error. Please check your API key and network connection. Details: ${error.message}`;
    }
    return "Error: An unknown error occurred while solving the script error.";
  }
};
