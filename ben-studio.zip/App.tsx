import React, { useState } from 'react';
import { Header } from './components/Header';
import { ScriptGenerator } from './components/ScriptGenerator';
import { ErrorSolver } from './components/ErrorSolver';
import { Icon } from './components/Icon';

type ActiveTab = 'generator' | 'solver';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('generator');

  const TabButton = ({
    tabName,
    label,
    icon,
  }: {
    tabName: ActiveTab;
    label: string;
    icon: 'zap' | 'wrench';
  }) => {
    const isActive = activeTab === tabName;
    return (
      <button
        onClick={() => setActiveTab(tabName)}
        className={`flex items-center justify-center px-6 py-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black ${
          isActive
            ? 'bg-cyan-500 text-white shadow-md'
            : 'text-gray-300 hover:bg-gray-800/60 hover:text-white'
        }`}
        role="tab"
        aria-selected={isActive}
        aria-controls={`${tabName}-panel`}
        id={`${tabName}-tab`}
      >
        <Icon icon={icon} className="w-5 h-5 mr-2" />
        {label}
      </button>
    );
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="mb-8 flex justify-center space-x-2 sm:space-x-4" role="tablist" aria-label="App features">
          <TabButton tabName="generator" label="Script Generator" icon="zap" />
          <TabButton tabName="solver" label="Error Solver" icon="wrench" />
        </div>
        
        <div id="generator-panel" role="tabpanel" aria-labelledby="generator-tab" hidden={activeTab !== 'generator'}>
          {activeTab === 'generator' && <ScriptGenerator />}
        </div>
        <div id="solver-panel" role="tabpanel" aria-labelledby="solver-tab" hidden={activeTab !== 'solver'}>
          {activeTab === 'solver' && <ErrorSolver />}
        </div>
      </main>
    </div>
  );
};

export default App;
