import React from 'react';
import { Icon } from './Icon';

export const Header: React.FC = () => {
  return (
    <header className="bg-black/50 backdrop-blur-sm border-b border-gray-700/50 p-4 sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-center">
        <Icon icon="code" className="w-8 h-8 text-cyan-400 mr-3" />
        <h1 className="text-2xl font-bold text-white tracking-tight">
          BEN <span className="text-cyan-400">STUDIO</span>
        </h1>
      </div>
    </header>
  );
};