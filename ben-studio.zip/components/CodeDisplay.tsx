import React, { useState, useEffect } from 'react';
import { Icon } from './Icon';

interface CodeDisplayProps {
  script: string;
  title?: string;
}

export const CodeDisplay: React.FC<CodeDisplayProps> = ({ script, title = "AI Generated Script" }) => {
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied'>('idle');

  useEffect(() => {
    if (copyStatus === 'copied') {
      const timer = setTimeout(() => setCopyStatus('idle'), 2000);
      return () => clearTimeout(timer);
    }
  }, [copyStatus]);

  const handleCopy = () => {
    if (script) {
      navigator.clipboard.writeText(script);
      setCopyStatus('copied');
    }
  };

  return (
    <div className="bg-black/30 backdrop-blur-sm rounded-lg h-full flex flex-col relative border border-gray-700/50">
      <div className="flex justify-between items-center p-3 border-b border-gray-700/50">
        <div className="flex items-center">
            <Icon icon="robot" className="w-5 h-5 text-gray-400 mr-2" />
            <h3 className="text-lg font-semibold text-gray-200">{title}</h3>
        </div>
        <button
          onClick={handleCopy}
          disabled={!script}
          className="flex items-center px-3 py-1.5 bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:cursor-not-allowed disabled:text-gray-500 text-white rounded-md text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500"
          aria-label="Copy code to clipboard"
        >
          <Icon icon="clipboard" className="w-4 h-4 mr-2" />
          {copyStatus === 'copied' ? 'Copied!' : 'Copy'}
        </button>
      </div>
      <div className="p-4 overflow-auto flex-grow">
        {script ? (
          <pre className="text-sm">
            <code className="language-lua text-cyan-300 whitespace-pre-wrap break-words font-mono">
              {script}
            </code>
          </pre>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <p>The AI's response will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
};
