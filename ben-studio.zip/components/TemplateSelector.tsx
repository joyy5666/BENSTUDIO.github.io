
import React from 'react';
import { TEMPLATES } from '../constants';
import type { Template } from '../types';

interface TemplateSelectorProps {
  selectedTemplate: string;
  onSelectTemplate: (key: string) => void;
}

export const TemplateSelector: React.FC<TemplateSelectorProps> = ({ selectedTemplate, onSelectTemplate }) => {
  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-200 mb-3">
        1. Choose an Advanced Template
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {TEMPLATES.map((template: Template) => (
          <button
            key={template.key}
            onClick={() => onSelectTemplate(template.key)}
            className={`p-4 border rounded-lg text-left transition-all duration-200 transform hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-cyan-400 ${
              selectedTemplate === template.key
                ? 'bg-cyan-500/20 border-cyan-400'
                : 'bg-gray-800/50 border-gray-700 hover:border-cyan-500'
            }`}
          >
            <p className="font-bold text-white">{template.name}</p>
            <p className="text-sm text-gray-400 mt-1">{template.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
};
