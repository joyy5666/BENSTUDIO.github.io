import React, { useState, useCallback, useEffect } from 'react';
import { CodeDisplay } from './CodeDisplay';
import { Loader } from './Loader';
import { Icon } from './Icon';
import { generateScript } from '../services/geminiService';

type HistoryItem = {
  id: number;
  prompt: string;
  script: string;
};

const HISTORY_KEY = 'scriptGeneratorHistory';

export const ScriptGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [generatedScript, setGeneratedScript] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem(HISTORY_KEY);
      if (savedHistory) {
        setHistory(JSON.parse(savedHistory));
      }
    } catch (e) {
      console.error("Failed to parse history from localStorage", e);
    }
  }, []);

  const handleGenerate = useCallback(async () => {
    if (!prompt.trim()) {
      setError('Please describe the script you want in the text area.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedScript('');

    const result = await generateScript(prompt);

    if (result.startsWith('Error:')) {
        setError(result);
    } else {
        setGeneratedScript(result);
        const newHistoryItem: HistoryItem = { id: Date.now(), prompt, script: result };
        setHistory(prevHistory => {
            const updatedHistory = [newHistoryItem, ...prevHistory].slice(0, 50); // Keep last 50
            localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
            return updatedHistory;
        });
    }

    setIsLoading(false);
  }, [prompt]);

  const loadFromHistory = (item: HistoryItem) => {
    setPrompt(item.prompt);
    setGeneratedScript(item.script);
  };
  
  const deleteFromHistory = (id: number) => {
    setHistory(prevHistory => {
        const updatedHistory = prevHistory.filter(item => item.id !== id);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
        return updatedHistory;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem(HISTORY_KEY);
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Left Column: Inputs */}
      <div className="flex flex-col gap-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-200 mb-3">
            Describe Your Script
          </h3>
          <p className="text-sm text-gray-400 mb-3">
            Provide a detailed description of the Lua script you want the AI to generate. The more specific you are, the better the result will be.
          </p>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g., 'a red brick that disappears when touched' or 'a function that calculates the distance between two points'"
            className="w-full h-40 p-4 bg-gray-900/70 backdrop-blur-sm border border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none transition-colors"
            aria-label="Script description"
          />
        </div>
        
        {error && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-300 p-3 rounded-lg text-sm" role="alert">
                {error}
            </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={isLoading || !prompt}
          className="flex items-center justify-center w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-lg text-lg transition-all duration-200 disabled:bg-gray-700 disabled:cursor-not-allowed transform hover:scale-[1.02] disabled:scale-100 focus:outline-none focus:ring-4 focus:ring-cyan-500/50"
        >
          <Icon icon="zap" className={`w-6 h-6 mr-2 ${isLoading ? 'animate-pulse' : ''}`} />
          {isLoading ? 'Generating...' : 'Generate Script'}
        </button>
        
        {/* History Section */}
        <div className="mt-8">
            <hr className="border-t border-gray-700/50 mb-6" />
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-200">Generation History</h3>
                {history.length > 0 && (
                    <button onClick={clearHistory} className="flex items-center text-sm text-gray-400 hover:text-red-400 transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 rounded-md px-2 py-1">
                        <Icon icon="trash" className="w-4 h-4 mr-1.5" />
                        Clear All
                    </button>
                )}
            </div>
            {history.length === 0 ? (
                <div className="text-center py-4 text-gray-500 bg-gray-900/50 rounded-lg">
                    <p>Your generated scripts will appear here.</p>
                </div>
            ) : (
                <ul className="space-y-2 max-h-72 overflow-y-auto pr-2">
                    {history.map(item => (
                        <li key={item.id} className="bg-gray-800/60 p-3 rounded-lg flex justify-between items-center group">
                            <p className="text-sm text-gray-300 truncate pr-4 flex-1">
                                {item.prompt}
                            </p>
                            <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => loadFromHistory(item)} className="text-cyan-400 hover:text-cyan-300" title="Load this entry">Load</button>
                                <button onClick={() => deleteFromHistory(item.id)} className="text-gray-500 hover:text-red-400" title="Delete this entry">
                                    <Icon icon="trash" className="w-4 h-4" />
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>

      </div>

      {/* Right Column: Output */}
      <div className="relative min-h-[500px] lg:min-h-0">
        {isLoading && <Loader />}
        <CodeDisplay script={generatedScript} />
      </div>
    </div>
  );
};