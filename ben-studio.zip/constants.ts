
import type { Template } from './types';

export const TEMPLATES: Template[] = [
  {
    key: 'game-object',
    name: 'Game Object (Roblox-style)',
    description: 'Create a new part with properties and behavior.',
    prompt: `Generate a Lua script that creates a new Part in a Roblox-like environment. The Part should be anchored, non-collidable, and have a specific color and size. It should also have a script attached that makes it slowly rotate. The user's request will specify the details.`,
  },
  {
    key: 'utility-function',
    name: 'Utility Function',
    description: 'Generate a reusable utility function.',
    prompt: `Create a Lua module that contains a single, well-documented utility function. The function's purpose is described by the user. Ensure the function has clear parameters and a return value.`,
  },
  {
    key: 'data-manager',
    name: 'Simple Data Manager',
    description: 'A module script to manage and save player data.',
    prompt: `Generate a Lua ModuleScript that acts as a simple data manager. It should have functions to get, set, and save player data. The user will describe what kind of data to manage. Assume a simple key-value store mechanism.`,
  },
  {
    key: 'event-handler',
    name: 'Event Handler',
    description: 'Connect a function to an event.',
    prompt: `Generate a Lua script that connects a function to an event. For example, listening for a player joining or a part being touched. The user will specify the event and the action to perform.`,
  },
];
