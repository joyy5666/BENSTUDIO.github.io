
export interface Template {
  key: string;
  name: string;
  description: string;
  prompt: string;
}
